﻿Prefab to PSD v2.0.1 空白捕获修订版
目标版本：Unity 2018.4.36f1。

已安装用户：解压 Upgrade ZIP，将其中 PrefabToPsd 文件夹覆盖到现有插件目录。
截图所示安装路径为 Assets/ThirdParty/PrefabToPsd，请在这个原目录覆盖。
项目中应仅保留一份 PrefabToPsd；重复放入 Assets/PrefabToPsd 会造成重复类编译错误。

首次安装：导入 Install 中的 .unitypackage，或复制 Source 中 Assets/PrefabToPsd。
升级后先运行 Tools > Prefab to PSD > Run Self Tests，然后重新导出。

本版新增 UGUI 正负校准与空白输出拦截、相机路径选择、浮点混合能力检查及诊断报告。
703 项托管检查和 130 项原导入器读取检查通过；未在本环境执行 Windows/D3D11 GPU 测试。
因此本版需在发生问题的 Unity 环境复测，不能将托管检查视为已证实 GPU 故障解决。

若仍失败，请提供项目 Temp/PrefabToPsdSelfTests/self-test-report.txt，
以及其中生成的 composite-rle.diagnostics.txt、composite-rle.preview.png、composite-rle.psd。
若捕获在写文件前已被拦截，则只有报告文件也是正常的。
